package com.lol.matching;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchingApplicationTests {

	@Test
	void contextLoads() {
	}

}
