package com.lol.matching.controller;

public class testController {
    
    static String test = "zz";
}
